/**
 * Tokens Plugin - Main Entry Point
 *
 * Provides comprehensive token usage analytics and management:
 * - Tracks token usage across all LLM requests
 * - Enforces global, per-user, and per-chat token limits
 * - Provides detailed analytics and cost estimation
 * - Real-time monitoring and notifications
 *
 * Uses: Generic Hooks System
 */


// Import hook handlers
const llmBeforeGenerateHandler = require('./app/hooks/llmBeforeGenerateHandler');
const llmAfterGenerateHandler = require('./app/hooks/llmAfterGenerateHandler');
const chatAfterMessageHandler = require('./app/hooks/chatAfterMessageHandler');

/**
 * Load method - called by pluginLoader with API
 * @param {Object} pluginAPI - { hookService, HOOKS, pluginLoader, registerView, registerClientComponent }
 */

function load(pluginAPI) {
  try {
    const { hookService, HOOKS, registerView, registerClientComponent } = pluginAPI;
    const master = require('mastercontroller');

     // Register this plugin directory as a component so MasterController can find controllers
      // This allows the routes to resolve "api/rag#method" to this plugin's controllers
     master.component("bb-plugins", "tokens-plugin");

      registerView('tokens-settings', 'admin/tokens/settings/page', {
        title: 'Token Settings',
        capability: 'manage_options',
        icon: 'settings'
      });

      registerView('tokens-analytics', 'admin/tokens/analytics/page', {
        title: 'Token Analytics',
        capability: 'manage_options',
        icon: 'activity'
      });

      // Also register admin views as client components for static loading
      // This enables Next.js to resolve dependencies at build time
      registerClientComponent('TokenSettingsPage', 'admin/tokens/settings/page.js', {
        description: 'Token Settings admin page',
        usage: 'admin-view',
        viewSlug: 'tokens-settings'
      });
      registerClientComponent('TokenAnalyticsPage', 'admin/tokens/analytics/page.js', {
        description: 'Token Analytics admin page',
        usage: 'admin-view',
        viewSlug: 'tokens-analytics'
      });


    // Register all hooks
    registerHooks(hookService, HOOKS);


    console.log('✓ Tokens Plugin loaded successfully');
  } catch (error) {
    console.error('❌ Error loading Tokens Plugin:', error.message);
    console.error(error.stack);
    throw error;
  }
}

/**
 * Activate method - called when plugin is activated
 */
async function activate() {
  try {
    console.log('⚡ Activating Tokens Plugin...');
    // Additional activation logic if needed
    console.log('✓ Tokens Plugin activated successfully');
  } catch (error) {
    console.error('❌ Error activating Tokens Plugin:', error.message);
    throw error;
  }
}

/**
 * Deactivate method - called when plugin is deactivated
 */
async function deactivate() {
  try {
    console.log('🔌 Deactivating Tokens Plugin...');
    // Cleanup logic if needed
    console.log('✓ Tokens Plugin deactivated successfully');
  } catch (error) {
    console.error('❌ Error deactivating Tokens Plugin:', error.message);
    throw error;
  }
}


/**
 * Register all plugin hooks
 */
function registerHooks(hookService, HOOKS) {
  try {
    console.log('🪝 Registering Tokens Plugin hooks...');

    // Register LLM_BEFORE_GENERATE hook - Check token limits before LLM requests
    hookService.addFilter(HOOKS.LLM_BEFORE_GENERATE, llmBeforeGenerateHandler, 10);
    console.log('  ✓ LLM_BEFORE_GENERATE: Check token limits');

    // Register LLM_AFTER_GENERATE hook - Capture token usage after LLM responses
    hookService.addAction(HOOKS.LLM_AFTER_GENERATE, llmAfterGenerateHandler, 10);
    console.log('  ✓ LLM_AFTER_GENERATE: Capture token usage');

    // Register CHAT_AFTER_MESSAGE hook - Log message-level events
    hookService.addAction(HOOKS.CHAT_AFTER_MESSAGE, chatAfterMessageHandler, 10);
    console.log('  ✓ CHAT_AFTER_MESSAGE: Log message events');

    // Register ADMIN_MENU hook - Add admin menu items
    hookService.addAction(HOOKS.ADMIN_MENU, async (context) => {
      // Add top-level Tokens menu
      context.addMenuItem({
        id: 'tokens',
        label: 'Tokens',
        url: '/bb-admin/plugin/tokens-analytics', // WordPress-style: /bb-admin/plugin/[slug]
        icon: 'Activity',
        position: 35
      });

      // Add Analytics submenu
      context.addSubmenuItem('tokens', {
        label: 'Analytics',
        url: '/bb-admin/plugin/tokens-analytics'
      });

      // Add Settings submenu
      context.addSubmenuItem('tokens', {
        label: 'Settings',
        url: '/bb-admin/plugin/tokens-settings'
      });
    }, 10);
    console.log('  ✓ ADMIN_MENU: Add admin menu items');

    console.log('✓ All Tokens Plugin hooks registered');
  } catch (error) {
    console.error('❌ Error registering hooks:', error.message);
    throw error;
  }
}


module.exports = { load, activate, deactivate };
